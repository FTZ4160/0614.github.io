package com.feige.chuanshu;

import android.app.Application;
import android.webkit.WebView;

/**
 * 飞鸽传书 - Application
 */
public class FeigeApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        
        // Android 9+ WebView 数据目录加密等配置
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            String processName = getProcessName();
            if (!getPackageName().equals(processName)) {
                WebView.setDataDirectorySuffix(processName);
            }
        }
    }
}
