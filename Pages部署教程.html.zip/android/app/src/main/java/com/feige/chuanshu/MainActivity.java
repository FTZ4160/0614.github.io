package com.feige.chuanshu;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 飞鸽传书 - 主Activity
 * 功能：
 * 1. WebView 加载 H5 页面
 * 2. 地理位置权限申请与回调
 * 3. 相册/存储权限申请与文件选择
 * 4. 相机权限申请与拍照
 * 5. 文件上传支持（<input type="file">）
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "FeigeChuanshu";
    
    // 权限请求码
    private static final int REQUEST_LOCATION_PERMISSION = 1001;
    private static final int REQUEST_STORAGE_PERMISSION = 1002;
    private static final int REQUEST_CAMERA_PERMISSION = 1003;
    
    // 文件上传相关
    private ValueCallback<Uri[]> mUploadMessage;
    private String mCameraPhotoPath;
    private final static int FILECHOOSER_RESULTCODE = 1;

    private WebView webView;
    private ProgressBar progressBar;
    private View errorLayout;

    // 待处理的权限回调
    private PermissionRequest pendingPermissionRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        errorLayout = findViewById(R.id.errorLayout);

        setupWebView();
        loadMainPage();

        // 重试按钮
        findViewById(R.id.retryButton).setOnClickListener(v -> {
            errorLayout.setVisibility(View.GONE);
            loadMainPage();
        });
    }

    /**
     * 配置 WebView
     */
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        
        // 基础设置
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        
        // 缩放设置
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        
        // 缓存设置
        webSettings.setAppCacheEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setAppCachePath(getDir("appcache", 0).getPath());
        
        // 文件访问
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // 地理定位
        webSettings.setGeolocationEnabled(true);
        webSettings.setGeolocationDatabasePath(getDir("geolocation", 0).getPath());
        
        // 混合内容（允许http和https混合）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        
        // 文字大小
        webSettings.setTextZoom(100);
        webSettings.setDefaultTextEncodingName("UTF-8");

        // WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(0);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                errorLayout.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    errorLayout.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // 处理外部链接
                if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        // WebChromeClient - 处理文件上传、定位、权限请求等
        webView.setWebChromeClient(new WebChromeClient() {
            
            // 页面加载进度
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                progressBar.setProgress(newProgress);
                if (newProgress >= 100) {
                    progressBar.postDelayed(() -> progressBar.setVisibility(View.GONE), 200);
                }
            }

            // 文件上传（Android 5.0+）
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                           FileChooserParams fileChooserParams) {
                if (mUploadMessage != null) {
                    mUploadMessage.onReceiveValue(null);
                }
                mUploadMessage = filePathCallback;
                
                showFileChooser(fileChooserParams);
                return true;
            }

            // 地理定位权限请求
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, 
                                                          GeolocationPermissions.Callback callback) {
                Log.d(TAG, "onGeolocationPermissionsShowPrompt: " + origin);
                pendingGeoCallback = callback;
                pendingGeoOrigin = origin;
                requestLocationPermission();
            }

            // 其他权限请求（相机、麦克风等）
            @Override
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            public void onPermissionRequest(PermissionRequest request) {
                Log.d(TAG, "onPermissionRequest: " + request.getResources());
                pendingPermissionRequest = request;
                
                String[] resources = request.getResources();
                boolean needCamera = false;
                for (String res : resources) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                        needCamera = true;
                        break;
                    }
                }
                
                if (needCamera) {
                    requestCameraPermission();
                } else {
                    // 其他权限默认拒绝或按需处理
                    if (pendingPermissionRequest != null) {
                        pendingPermissionRequest.deny();
                        pendingPermissionRequest = null;
                    }
                }
            }
        });
    }

    /**
     * 加载主页（本地 assets）
     */
    private void loadMainPage() {
        // 加载本地HTML文件
        webView.loadUrl("file:///android_asset/index.html");
    }

    // ============================================
    // 文件选择处理
    // ============================================

    private void showFileChooser(WebChromeClient.FileChooserParams params) {
        boolean isImage = false;
        boolean allowCamera = false;
        
        if (params.getAcceptTypes() != null) {
            for (String type : params.getAcceptTypes()) {
                if (type.contains("image")) {
                    isImage = true;
                    allowCamera = true;
                    break;
                }
            }
        }
        
        if (isImage) {
            // 图片选择：检查存储权限
            if (hasStoragePermission()) {
                openImageChooser(allowCamera);
            } else {
                requestStoragePermissionForUpload();
            }
        } else {
            // 通用文件选择
            openFileChooser();
        }
    }

    private void openImageChooser(boolean allowCamera) {
        List<Intent> intentList = new ArrayList<>();
        
        // 相册选择
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, 
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryIntent.setType("image/*");
        intentList.add(galleryIntent);
        
        // 相机拍照（可选）
        if (allowCamera && hasCameraPermission()) {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                    cameraIntent.putExtra("PhotoPath", mCameraPhotoPath);
                } catch (IOException ex) {
                    Log.e(TAG, "Unable to create Image File", ex);
                }
                if (photoFile != null) {
                    mCameraPhotoPath = photoFile.getAbsolutePath();
                    Uri photoURI = FileProvider.getUriForFile(this,
                            getApplicationContext().getPackageName() + ".fileprovider",
                            photoFile);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    intentList.add(cameraIntent);
                }
            }
        }
        
        Intent chooserIntent = Intent.createChooser(new Intent(Intent.ACTION_PICK), 
                "选择照片");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, 
                intentList.toArray(new Intent[0]));
        
        startActivityForResult(chooserIntent, FILECHOOSER_RESULTCODE);
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(Intent.createChooser(intent, "选择文件"), FILECHOOSER_RESULTCODE);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(new Date());
        String imageFileName = "Feige_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == FILECHOOSER_RESULTCODE) {
            if (null == mUploadMessage) return;
            
            Uri[] results = null;
            
            if (resultCode == Activity.RESULT_OK) {
                if (data != null && data.getData() != null) {
                    // 从相册选择
                    results = new Uri[]{data.getData()};
                } else if (mCameraPhotoPath != null) {
                    // 拍照
                    File file = new File(mCameraPhotoPath);
                    if (file.exists()) {
                        results = new Uri[]{Uri.fromFile(file)};
                    }
                }
                
                // 处理多选
                if (data != null && data.getClipData() != null) {
                    ClipData clipData = data.getClipData();
                    results = new Uri[clipData.getItemCount()];
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        results[i] = clipData.getItemAt(i).getUri();
                    }
                }
            }
            
            mUploadMessage.onReceiveValue(results);
            mUploadMessage = null;
            mCameraPhotoPath = null;
        }
    }

    // ============================================
    // 权限申请 - 位置权限
    // ============================================

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, 
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (hasLocationPermission()) {
            // 已有权限，直接授予
            grantGeolocationPermission(true);
            return;
        }

        // 显示解释弹窗
        new AlertDialog.Builder(this, R.style.FeigeDialog)
                .setTitle(R.string.permission_location_title)
                .setMessage(R.string.permission_location_message)
                .setPositiveButton(R.string.grant_permission, (dialog, which) -> {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                            },
                            REQUEST_LOCATION_PERMISSION);
                })
                .setNegativeButton(R.string.deny_permission, (dialog, which) -> {
                    grantGeolocationPermission(false);
                    Toast.makeText(MainActivity.this, 
                            R.string.permission_denied, Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .show();
    }

    private void grantGeolocationPermission(boolean allow) {
        if (pendingGeoCallback != null && pendingGeoOrigin != null) {
            pendingGeoCallback.invoke(pendingGeoOrigin, allow, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    // ============================================
    // 权限申请 - 存储/相册权限
    // ============================================

    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestStoragePermissionForUpload() {
        if (hasStoragePermission()) {
            openImageChooser(true);
            return;
        }

        new AlertDialog.Builder(this, R.style.FeigeDialog)
                .setTitle(R.string.permission_storage_title)
                .setMessage(R.string.permission_storage_message)
                .setPositiveButton(R.string.grant_permission, (dialog, which) -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                                REQUEST_STORAGE_PERMISSION);
                    } else {
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                REQUEST_STORAGE_PERMISSION);
                    }
                })
                .setNegativeButton(R.string.deny_permission, (dialog, which) -> {
                    if (mUploadMessage != null) {
                        mUploadMessage.onReceiveValue(null);
                        mUploadMessage = null;
                    }
                    Toast.makeText(MainActivity.this,
                            R.string.permission_denied, Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .show();
    }

    // ============================================
    // 权限申请 - 相机权限
    // ============================================

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCameraPermission() {
        if (hasCameraPermission()) {
            if (pendingPermissionRequest != null) {
                pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                pendingPermissionRequest = null;
            }
            return;
        }

        new AlertDialog.Builder(this, R.style.FeigeDialog)
                .setTitle(R.string.permission_camera_title)
                .setMessage(R.string.permission_camera_message)
                .setPositiveButton(R.string.grant_permission, (dialog, which) -> {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            REQUEST_CAMERA_PERMISSION);
                })
                .setNegativeButton(R.string.deny_permission, (dialog, which) -> {
                    if (pendingPermissionRequest != null) {
                        pendingPermissionRequest.deny();
                        pendingPermissionRequest = null;
                    }
                })
                .setCancelable(false)
                .show();
    }

    // ============================================
    // 权限请求回调
    // ============================================

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        switch (requestCode) {
            case REQUEST_LOCATION_PERMISSION: {
                boolean granted = false;
                for (int result : grantResults) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        granted = true;
                        break;
                    }
                }
                grantGeolocationPermission(granted);
                
                if (!granted && !ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    // 用户勾选了"不再询问"，引导去设置
                    showPermissionSettingsDialog("位置");
                }
                break;
            }
            
            case REQUEST_STORAGE_PERMISSION: {
                boolean granted = grantResults.length > 0 
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED;
                if (granted) {
                    openImageChooser(true);
                } else {
                    if (mUploadMessage != null) {
                        mUploadMessage.onReceiveValue(null);
                        mUploadMessage = null;
                    }
                    Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show();
                    
                    if (!ActivityCompat.shouldShowRequestPermissionRationale(
                            this, Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                                    ? Manifest.permission.READ_MEDIA_IMAGES
                                    : Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        showPermissionSettingsDialog("相册");
                    }
                }
                break;
            }
            
            case REQUEST_CAMERA_PERMISSION: {
                boolean granted = grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED;
                if (granted) {
                    if (pendingPermissionRequest != null) {
                        pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                        pendingPermissionRequest = null;
                    }
                } else {
                    if (pendingPermissionRequest != null) {
                        pendingPermissionRequest.deny();
                        pendingPermissionRequest = null;
                    }
                }
                break;
            }
        }
    }

    /**
     * 显示跳转设置的弹窗
     */
    private void showPermissionSettingsDialog(String permissionName) {
        new AlertDialog.Builder(this, R.style.FeigeDialog)
                .setTitle("权限被拒绝")
                .setMessage("您已拒绝" + permissionName + "权限且勾选了不再询问。\n如需使用该功能，请前往设置中手动开启。")
                .setPositiveButton(R.string.go_to_settings, (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ============================================
    // 返回键处理
    // ============================================

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ============================================
    // 生命周期
    // ============================================

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
