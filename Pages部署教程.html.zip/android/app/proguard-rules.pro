# 飞鸽传书 - ProGuard 规则

# 保留 WebView 相关类
-keep class android.webkit.** { *; }
-keep class androidx.webkit.** { *; }

# 保留 JavaScript 接口
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# 保留 AndroidX
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# 保留 Material Design
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# 保留 FileProvider
-keep class androidx.core.content.FileProvider { *; }

# 保留 WebChromeClient 内部类
-keep class android.webkit.WebChromeClient** { *; }
-keep class android.webkit.WebViewClient** { *; }
-keep class android.webkit.GeolocationPermissions** { *; }
-keep class android.webkit.PermissionRequest** { *; }
-keep class android.webkit.ValueCallback { *; }
