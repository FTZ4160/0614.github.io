# 飞鸽传书 - Android 应用

> 让鸟儿传递你的心意 —— 一款温暖治愈的书信传递应用

## 📋 项目简介

飞鸽传书是一款基于地理位置的社交应用，用户可以通过各种鸟类信使（鸽子、游隼、燕子等）向好友传递消息，消息传递时间根据两人之间的实际距离和鸟类飞行速度计算。

### 核心功能
- 🕊️ **6种鸟类信使**：鸽子、游隼、燕子、大雁、猫头鹰、麻雀，各有不同飞行速度
- 📱 **手机号注册登录**：真实的用户系统，数据本地存储
- 👥 **好友系统**：通过手机号搜索添加好友
- 📍 **真实地理位置**：基于GPS定位，使用Haversine公式计算真实距离
- 📷 **自定义头像**：支持相册选图和拍照作为头像
- 🌾 **米粒经济系统**：1元=100米粒，10米粒飞一次

## 🚀 快速开始

### 环境要求
- Android Studio Hedgehog (2023.1.1) 或更高版本
- JDK 17+
- Android SDK 34
- Gradle 8.0+

### 构建步骤

1. **打开项目**
   ```
   使用 Android Studio 打开 android/ 目录
   ```

2. **同步 Gradle**
   ```
   等待 Gradle 自动同步完成
   ```

3. **连接设备或启动模拟器**
   - 最低支持 Android 5.0 (API 21)
   - 推荐 Android 8.0+

4. **运行应用**
   ```
   点击 Run 按钮 (Shift + F10)
   ```

### 打包 Release APK

1. 生成签名密钥（首次）
   ```bash
   keytool -genkey -v -keystore feige.keystore \
       -alias feige -keyalg RSA -keysize 2048 -validity 10000
   ```

2. 在 `app/build.gradle` 中配置签名
   ```groovy
   signingConfigs {
       release {
           storeFile file("feige.keystore")
           storePassword "your_password"
           keyAlias "feige"
           keyPassword "your_password"
       }
   }
   ```

3. 构建
   ```bash
   ./gradlew assembleRelease
   ```

4. 输出位置
   ```
   app/build/outputs/apk/release/app-release.apk
   ```

## 📱 权限说明

### 申请的权限及用途

| 权限 | 用途 | 触发时机 |
|------|------|----------|
| **ACCESS_FINE_LOCATION** | 获取精确地理位置，计算与好友的距离 | 用户主动点击"定位"按钮时 |
| **ACCESS_COARSE_LOCATION** | 获取粗略位置（备选） | 同上 |
| **READ_EXTERNAL_STORAGE** | 从相册选择照片作为头像（Android 12及以下） | 用户点击上传头像时 |
| **READ_MEDIA_IMAGES** | 从相册选择照片作为头像（Android 13+） | 用户点击上传头像时 |
| **CAMERA** | 拍照作为头像 | 用户选择拍照上传头像时 |
| **INTERNET** | 网络访问（H5页面加载） | 应用启动时 |
| **VIBRATE** | 消息提醒振动 | 消息送达时 |
| **POST_NOTIFICATIONS** | 推送通知（Android 13+） | 首次启动询问 |

### 权限合规说明

- ✅ 所有权限均有明确用途，且在 `AndroidManifest.xml` 中有注释说明
- ✅ 危险权限（位置、存储、相机）均采用**运行时申请**，用户主动触发时才申请
- ✅ 申请前弹出解释弹窗，说明权限用途
- ✅ 用户拒绝后引导至设置页手动开启
- ✅ 符合应用商店隐私政策审核要求

## 🏪 应用商店上架指南

### 华为应用市场
- 目标SDK：34
- 支持64位架构
- 隐私政策：需提供独立的隐私政策页面
- 权限说明：需在应用介绍中说明各权限用途

### 小米应用商店
- 需提供《隐私政策》链接
- 需填写《个人信息收集清单》
- 权限需逐项说明用途

### OPPO 应用商店
- 需通过 OPPO 隐私合规检测
- 需提供《开发者承诺书》

### vivo 应用商店
- 需通过 vivo 安全检测
- 目标SDK需 ≥ 30

### 腾讯应用宝
- 需提供软件著作权（可选）
- 需提供ICP备案（可选）

### 上架素材清单

| 素材 | 规格 | 数量 |
|------|------|------|
| 应用图标 | 512x512 PNG，圆角 | 1 |
| 应用截图 | 1080x1920 PNG | 3-5张 |
| 宣传图 | 1080x1920 PNG | 1张（可选） |
| 应用简介 | 50-500字 | 1 |
| 更新说明 | 50-500字 | 1 |
| 隐私政策 | 可访问的URL | 1 |
| 软件著作权 | PDF扫描件 | 1（可选） |

## 📁 项目结构

```
android/
├── app/
│   ├── build.gradle              # 应用级 Gradle 配置
│   ├── proguard-rules.pro        # 代码混淆规则
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml    # 清单文件（权限声明）
│           ├── assets/
│           │   └── index.html         # H5 页面
│           ├── java/com/feige/chuanshu/
│           │   ├── MainActivity.java  # 主 Activity（WebView + 权限）
│           │   └── FeigeApplication.java
│           └── res/
│               ├── drawable/           # 图标资源
│               ├── layout/             # 布局文件
│               ├── mipmap-*/           # 启动图标
│               ├── values/             # 字符串、颜色、主题
│               └── xml/                # FileProvider 配置等
├── build.gradle                   # 项目级 Gradle 配置
├── settings.gradle                # 模块设置
└── gradle.properties              # Gradle 属性
```

## 🔧 核心技术

- **WebView + H5**：应用主体使用 H5 实现，原生壳提供权限能力
- **运行时权限申请**：符合 Android 6.0+ 权限模型
- **FileProvider**：兼容 Android 7.0+ 文件共享
- **分区存储**：适配 Android 10+ 分区存储机制
- **Scoped Storage**：适配 Android 13+ READ_MEDIA_IMAGES 权限

## 📄 隐私政策要点（上架必备）

应用在收集、使用个人信息时遵循以下原则：

1. **位置信息**：仅用于计算距离，不上传服务器，仅存储在本地
2. **相册/照片**：仅读取用户主动选择的照片作为头像
3. **用户数据**：所有用户数据存储在本地，开发者无法获取
4. **第三方SDK**：本应用不集成任何第三方统计、广告SDK

## 📞 技术支持

如有问题，请参考以下资源：
- Android 官方文档：https://developer.android.com/
- WebView 指南：https://developer.android.com/guide/webapps/webview

---

**飞鸽传书** · 让每一封信都充满期待 🕊️
